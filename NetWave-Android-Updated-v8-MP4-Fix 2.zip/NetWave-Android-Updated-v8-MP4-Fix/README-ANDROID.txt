SOCIAL HUB ANDROID - UPDATED SOURCE

This project keeps the original desktop source in original-desktop-source and the Android Capacitor project in android-app.

ANDROID CHANGES IN THIS UPDATE
- YouTube card's Ad-Free button calls a native Android WebView activity, so YouTube opens inside Social Hub rather than a Chrome Custom Tab.
- The in-app YouTube WebView filters a small list of known advertising domains and hides selected ad containers with CSS. This is best-effort only: YouTube may still show ads, and login/playback behavior depends on Android System WebView and YouTube.
- The in-app browser has a redesigned Download button. It accepts an authorized direct media-file URL (MP4, WebM, MOV, M4V, MP3, M4A) and sends it to Android DownloadManager, saving under Downloads/SocialHub. It shows an Android completion notification. A YouTube watch URL is not a direct media file and is rejected instead of saving a misleading HTML page.
- The YouTube browser includes a full-screen landscape control. It changes orientation without reloading the WebView, so the current playback session/time is retained. A long upward swipe in the upper/player area also requests landscape; swipe down, tap the floating exit control, or use Back to return to portrait. HTML5 fullscreen requests are handled through the WebChromeClient fullscreen callback.
- The app layout and download panel include Android safe-area spacing so content is less likely to sit beneath the status/navigation bars.

IMPORTANT DOWNLOAD LIMITATION
This build does not extract YouTube video formats, resolve YouTube stream URLs, or bypass YouTube protections/restrictions. Therefore it does not show selectable YouTube resolutions. Download only media you own or are authorized to download, using a direct media URL where downloads are permitted.

BUILD ON MAC
1. Open Terminal in the android-app folder.
2. Run: npm install
3. Run: npx cap sync android
4. Open Android Studio: npx cap open android
5. Build > Assemble Project / click the hammer icon.

The source ZIP does not include node_modules, Gradle caches, local.properties, or generated build output. Those are recreated by npm/Android Studio. The project could not be rebuilt in the preparation environment because Gradle needed to download its distribution and network access was unavailable. Please build on the Mac using the already configured Android Studio/Gradle installation and report any build error screenshot.
