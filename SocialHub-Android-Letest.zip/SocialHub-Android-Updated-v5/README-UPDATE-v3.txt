Social Hub Android update v3

Changes in this update:
- Removed whole-WebView touch gesture handling. Only an upward swipe that starts inside the YouTube video player can request landscape mode.
- Removed downward swipe-to-exit. Use the landscape/exit buttons to leave landscape mode.
- Added Android system-bar insets to the YouTube browser activity root so the top action bar (including Download) sits below the status bar and content stays above the navigation bar.
- Playback remains in the same WebView; orientation is changed without reloading the page.

Build:
1. Open android-app in Terminal.
2. Run npm install
3. Run npx cap sync android
4. Run npx cap open android
5. Build the debug APK from Android Studio.

Note: Android/Gradle build could not be run in this environment because Gradle 8.11.1 was not cached and the environment could not reach services.gradle.org. Please test the player-only upward swipe and Download button position on the target phone.
