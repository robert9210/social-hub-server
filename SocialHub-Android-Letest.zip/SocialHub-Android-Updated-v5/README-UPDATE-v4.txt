Social Hub Android Update v4

Changes in this update:
- Replaced the basic Download AlertDialog with a custom bottom-sheet style Download Manager popup.
- Added a short slide-up entrance animation.
- Added the configured Render cloud server URL: https://social-hub-server-avmq.onrender.com
- When the popup opens, the app checks the server /health endpoint and displays connection status.
- Existing direct MP4/WebM/MOV/M4V/MP3/M4A URL downloading remains through Android DownloadManager.
- YouTube URLs are identified and show a clear message because the current cloud backend only exposes / and /health; it does not yet provide video metadata, resolution discovery, or a download endpoint.

Important limitations:
- This update does NOT implement YouTube stream extraction or protected-stream downloading.
- It does NOT claim YouTube video resolutions are available.
- The Render service must remain deployed at the configured URL for the status indicator to show connected. Render free instances may sleep and take time to wake.

Build on Mac:
1. Extract this ZIP.
2. Open Terminal in the android-app folder.
3. Run: npm install
4. Run: npx cap sync android
5. Run: npx cap open android
6. Build the debug APK from Android Studio.

Build verification: The ZIP contents were checked. An Android Gradle build could not be run in this environment because Gradle 8.11.1 was not cached and services.gradle.org could not be reached. Please build on the Mac where Android Studio/Gradle is configured.
