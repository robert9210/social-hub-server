SOCIAL HUB ANDROID - UPDATE V5

Based on the supplied SocialHub-Android-Updated-v4 ZIP.

Changes:
1. Updated the YouTube screen's native Download toolbar button to a rounded black pill with white download symbol/text and white outline, matching the supplied reference style.
2. Download Manager now accepts youtube.com and youtu.be URLs (including youtu.be short links), checks real available video heights from the cloud backend, lets the user select a resolution or MP3, and queues the chosen file through Android DownloadManager.
3. Downloads are saved to Downloads/SocialHub and use Android's standard download notification.
4. Added social-hub-server/ containing the API backend, Dockerfile, and Render deployment notes.
5. Kept existing player gesture, orientation, safe-area, and browser logic unchanged.

IMPORTANT: The new backend must be deployed to the connected Render service before YouTube format lookup/download will work. See social-hub-server/RENDER-SETUP.txt. For reliable yt-dlp + FFmpeg installation, configure Render to use Docker and point it at the supplied Dockerfile. The app's old server does not yet expose /api/info or /api/download.

Only download content you own or have permission to save. The service does not bypass DRM or access controls. Availability depends on YouTube and yt-dlp compatibility. Render free instances may time out or run out of resources for larger downloads.

Build Android:
  cd android-app
  npm install
  npx cap sync android
  npx cap open android

Then build the APK from Android Studio. No APK build is included in this ZIP.
