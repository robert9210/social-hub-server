SOCIAL HUB ANDROID - UPDATE V6

Based on the supplied SocialHub-Android-Updated-v5 ZIP.

ANDROID CHANGES
1. Kept the native YouTube browser, toolbar, Download Manager bottom sheet, landscape/player gestures, safe-area handling, and best-effort ad filtering.
2. The native Download Manager now accepts authorized direct media-file links ending in MP4, WebM, MOV, M4V, MP3, or M4A.
3. Direct media downloads are queued through Android DownloadManager and saved to Downloads/SocialHub with Android's normal completion notification.
4. YouTube links are checked for public metadata through the cloud server. The app clearly reports that a direct YouTube download is unavailable rather than showing fabricated resolutions or attempting to extract protected streams.
5. Other app screens and existing Capacitor/native browser behavior are retained.

IMPORTANT YOUTUBE LIMITATION
YouTube's public video metadata endpoint does not provide direct MP4/MP3 stream URLs or selectable download resolutions. This update does not use yt-dlp, cookies, proxy rotation, PO-token workarounds, or access-control bypasses. Use YouTube's official Download feature where available, or a creator-provided direct media-file link when you have permission to save it.

BACKEND UPDATE
The social-hub-server folder now contains a minimal Node 22 Dockerfile and an API that:
- serves / and /health;
- reads public YouTube title/thumbnail metadata through YouTube oEmbed;
- explicitly reports downloadAvailable=false for YouTube links;
- refuses YouTube stream-download requests.

RENDER DEPLOYMENT
The backend is separate from the Android project. To update the existing Render service:
1. Open the GitHub repository connected to the Render service (social-hub-server).
2. Replace its server.js and package.json with the files from this ZIP's social-hub-server folder.
3. Add the Dockerfile from that same folder to the repository root.
4. Commit/push the changes and let Render deploy. Keep the existing service URL: https://social-hub-server-avmq.onrender.com
5. Check https://social-hub-server-avmq.onrender.com/health. It should return {"status":"ok"}.

ANDROID BUILD ON MAC
1. Extract this ZIP.
2. Open Terminal in the android-app folder.
3. Run: npm install
4. Run: npx cap sync android
5. Run: npx cap open android
6. In Android Studio, build the debug APK (Build > Build Bundle(s) / APK(s) > Build APK(s)).

NOTES
- The included previous APK is only the older build; rebuild after syncing the updated source.
- Download only direct media files you own or have permission to save.
- Android DownloadManager depends on the media host allowing direct file downloads. Expired signed URLs, login-only links, or servers that block download requests may fail.
- YouTube metadata may be unavailable for videos whose public oEmbed data is not exposed.
