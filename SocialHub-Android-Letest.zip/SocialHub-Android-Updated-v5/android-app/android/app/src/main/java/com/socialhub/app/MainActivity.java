package com.socialhub.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override public void onCreate(android.os.Bundle savedInstanceState) {
    registerPlugin(YoutubeBrowserPlugin.class);
    super.onCreate(savedInstanceState);
  }
}
