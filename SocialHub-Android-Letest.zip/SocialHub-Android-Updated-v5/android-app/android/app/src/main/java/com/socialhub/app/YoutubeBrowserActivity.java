package com.socialhub.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.FrameLayout;
import android.app.Dialog;
import android.graphics.drawable.GradientDrawable;
import android.view.animation.TranslateAnimation;
import android.view.Window;
import android.view.WindowManager;
import java.net.HttpURLConnection;
import java.net.URL;
import android.os.Environment;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import android.webkit.JavascriptInterface;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class YoutubeBrowserActivity extends Activity {
  private static final String CLOUD_SERVER_URL = "https://social-hub-server-avmq.onrender.com";
  private WebView web;
  private FrameLayout root;
  private LinearLayout column;
  private LinearLayout bar;
  private Button landscapeButton;
  private Button landscapeExitButton;
  private FrameLayout fullScreenContainer;
  private WebChromeClient.CustomViewCallback fullScreenCallback;
  private boolean landscape = false;
  private boolean adBlock = true;
  private final Set<String> blocked = new HashSet<>(Arrays.asList(
    "doubleclick.net", "googlesyndication.com", "googleadservices.com",
    "adservice.google.com", "imasdk.googleapis.com", "pagead2.googlesyndication.com"));
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(0xff15151b);
    getWindow().setNavigationBarColor(0xff15151b);
    root = new FrameLayout(this); root.setBackgroundColor(0xff101014);
    // Keep app controls inside the safe area, below the status bar and above navigation keys.
    ViewCompat.setOnApplyWindowInsetsListener(root, (view, windowInsets) -> {
      Insets systemBars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
      view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
      return windowInsets;
    });
    column = new LinearLayout(this); column.setOrientation(LinearLayout.VERTICAL); root.addView(column, new FrameLayout.LayoutParams(-1, -1));
    bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(8,6,8,6); bar.setBackgroundColor(0xff202027);
    Button back = makeBarButton("‹", "Back"); back.setOnClickListener(v -> finish());
    TextView label = new TextView(this); label.setText("YouTube  •  AdBlock"); label.setTextColor(0xffffffff); label.setTextSize(13); label.setGravity(Gravity.CENTER_VERTICAL); label.setSingleLine(true);
    landscapeButton = makeBarButton("⛶", "Full screen"); landscapeButton.setOnClickListener(v -> setLandscape(!landscape));
    Button download = makeDownloadButton(); download.setOnClickListener(v -> showDownloadDialog());
    bar.addView(back); bar.addView(label, new LinearLayout.LayoutParams(0, 48, 1)); bar.addView(landscapeButton); bar.addView(download); column.addView(bar);
    landscapeExitButton = makeBarButton("↙", "Exit landscape");
    landscapeExitButton.setVisibility(View.GONE);
    landscapeExitButton.setOnClickListener(v -> { if (fullScreenCallback != null) fullScreenCallback.onCustomViewHidden(); else setLandscape(false); });
    FrameLayout.LayoutParams exitLp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END); exitLp.setMargins(0, 12, 12, 0); root.addView(landscapeExitButton, exitLp);
    // Do not listen for gestures on the whole WebView: feed scrolling must remain normal.
    // The injected page script reports an upward swipe only when it starts on the video player.
    web = new WebView(this);
    web.addJavascriptInterface(new PlayerGestureBridge(), "SocialHubPlayer");
    web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setMediaPlaybackRequiresUserGesture(false);
    CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
    web.setWebChromeClient(new WebChromeClient() {
      @Override public void onShowCustomView(View view, CustomViewCallback callback) {
        if (fullScreenContainer != null) { callback.onCustomViewHidden(); return; }
        fullScreenCallback = callback;
        fullScreenContainer = new FrameLayout(YoutubeBrowserActivity.this);
        fullScreenContainer.setBackgroundColor(Color.BLACK);
        fullScreenContainer.addView(view, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        web.setVisibility(View.GONE);
        root.addView(fullScreenContainer, new FrameLayout.LayoutParams(-1, -1));
        setLandscape(true);
        landscapeExitButton.bringToFront();
      }
      @Override public void onHideCustomView() {
        if (fullScreenContainer != null) {
          root.removeView(fullScreenContainer); fullScreenContainer = null;
          web.setVisibility(View.VISIBLE);
        }
        fullScreenCallback = null;
        setLandscape(false);
      }
    });
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
      @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        if (adBlock) { String host = request.getUrl().getHost(); if (host != null) for (String d : blocked) if (host.equals(d) || host.endsWith("."+d)) return new android.webkit.WebResourceResponse("text/plain", "utf-8", new java.io.ByteArrayInputStream(new byte[0])); }
        return super.shouldInterceptRequest(view, request);
      }
      @Override public void onPageFinished(WebView view, String url) {
        if (adBlock) view.evaluateJavascript("(function(){var s=document.createElement('style');s.textContent='ytd-ad-slot-renderer,ytd-display-ad-renderer,ytd-promoted-sparkles-web-renderer,#player-ads,#masthead-ad,.video-ads{display:none!important}';document.documentElement.appendChild(s);})();", null);
        installPlayerOnlySwipe(view);
      }
    });
    column.addView(web, new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    ViewCompat.requestApplyInsets(root);
    web.loadUrl(getIntent().getStringExtra("url") == null ? "https://www.youtube.com" : getIntent().getStringExtra("url"));
  }

  private void installPlayerOnlySwipe(WebView target) {
    String script = "(function(){" +
      "if(window.__socialHubPlayerSwipeInstalled)return;window.__socialHubPlayerSwipeInstalled=true;" +
      "var start=null;" +
      "function playerAt(x,y,e){var path=(e&&e.composedPath)?e.composedPath():[];var candidates=path.slice();var el=document.elementFromPoint(x,y);if(el)candidates.push(el);" +
      "for(var i=0;i<candidates.length;i++){var n=candidates[i];if(!n||!n.getBoundingClientRect)continue;var isPlayer=(n.tagName==='VIDEO')||(n.id==='movie_player')||(n.classList&&(n.classList.contains('html5-video-player')||n.classList.contains('ytp-remote')))||(n.tagName&&n.tagName.toLowerCase()==='ytd-player');" +
      "if(isPlayer){var v=n.tagName==='VIDEO'?n:(n.querySelector?n.querySelector('video'):null);var r=(v||n).getBoundingClientRect();if(x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom)return true;}}return false;}" +
      "document.addEventListener('touchstart',function(e){var t=e.touches&&e.touches[0];if(!t)return;start=playerAt(t.clientX,t.clientY,e)?{x:t.clientX,y:t.clientY,time:Date.now()}:null;},{capture:true,passive:true});" +
      "document.addEventListener('touchend',function(e){if(!start)return;var t=e.changedTouches&&e.changedTouches[0];var s=start;start=null;if(!t)return;var dx=t.clientX-s.x,dy=t.clientY-s.y;if(dy < -125&&Math.abs(dy)>Math.abs(dx)*1.3&&Date.now()-s.time<1400&&window.SocialHubPlayer){window.SocialHubPlayer.enterLandscapeFromPlayer();}},{capture:true,passive:true});" +
      "document.addEventListener('touchcancel',function(){start=null;},{capture:true,passive:true});" +
      "})();";
    target.evaluateJavascript(script, null);
  }

  private class PlayerGestureBridge {
    @JavascriptInterface public void enterLandscapeFromPlayer() {
      runOnUiThread(() -> { if (!landscape && fullScreenContainer == null) setLandscape(true); });
    }
  }

  private Button makeBarButton(String symbol, String description) {
    Button b = new Button(this); b.setText(symbol); b.setTextColor(Color.WHITE); b.setTextSize(18); b.setTypeface(null, Typeface.BOLD);
    b.setAllCaps(false); b.setMinWidth(48); b.setMinimumWidth(48); b.setMinHeight(46); b.setMinimumHeight(46);
    b.setPadding(8,0,8,0); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff30303a)); b.setContentDescription(description); return b;
  }
  private void setLandscape(boolean enabled) {
    landscape = enabled;
    setRequestedOrientation(enabled ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    if (landscapeButton != null) landscapeButton.setText(enabled ? "↙" : "⛶");
    if (bar != null) bar.setVisibility(enabled ? View.GONE : View.VISIBLE);
    if (landscapeExitButton != null) landscapeExitButton.setVisibility(enabled ? View.VISIBLE : View.GONE);
    applySystemBars(enabled);
  }
  private void applySystemBars(boolean immersive) {
    if (android.os.Build.VERSION.SDK_INT >= 30) {
      Window w = getWindow();
      if (immersive) w.getInsetsController().hide(android.view.WindowInsets.Type.statusBars() | android.view.WindowInsets.Type.navigationBars());
      else w.getInsetsController().show(android.view.WindowInsets.Type.statusBars() | android.view.WindowInsets.Type.navigationBars());
    } else {
      int flags = immersive ? (View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY) : View.SYSTEM_UI_FLAG_VISIBLE;
      getWindow().getDecorView().setSystemUiVisibility(flags);
    }
  }
  private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

  private Button makeDownloadButton() {
    Button b = new Button(this);
    b.setText("↓  Download"); b.setTextColor(0xff17171c); b.setTextSize(14);
    b.setTypeface(null, Typeface.BOLD); b.setAllCaps(false);
    b.setPadding(dp(17), 0, dp(17), 0); b.setMinWidth(0); b.setMinimumWidth(0);
    b.setMinHeight(dp(42)); b.setMinimumHeight(dp(42));
    GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.WHITE);
    bg.setCornerRadius(dp(30)); bg.setStroke(dp(1.5f), 0xff17171c);
    b.setBackground(bg); b.setContentDescription("Download");
    return b;
  }

  private void showDownloadDialog() {
    Dialog dialog = new Dialog(this);
    LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
    panel.setPadding(dp(22), dp(18), dp(22), dp(22));
    GradientDrawable panelBg = new GradientDrawable(); panelBg.setColor(0xff1c1c24);
    panelBg.setCornerRadii(new float[]{dp(22),dp(22),dp(22),dp(22),dp(0),dp(0),dp(0),dp(0)}); panel.setBackground(panelBg);

    TextView handle = new TextView(this); handle.setText("━━━━━━━━"); handle.setTextColor(0xff555563);
    handle.setGravity(Gravity.CENTER); handle.setTextSize(14); panel.addView(handle, new LinearLayout.LayoutParams(-1, dp(18)));
    TextView title = new TextView(this); title.setText("Download Manager"); title.setTextColor(Color.WHITE);
    title.setTextSize(20); title.setTypeface(null, Typeface.BOLD); title.setPadding(0, dp(8), 0, dp(3)); panel.addView(title);
    TextView subtitle = new TextView(this); subtitle.setText("Paste a YouTube link or an authorized direct media-file link");
    subtitle.setTextColor(0xffa9a9b5); subtitle.setTextSize(13); subtitle.setPadding(0, 0, 0, dp(16)); panel.addView(subtitle);
    TextView fieldLabel = new TextView(this); fieldLabel.setText("VIDEO / MEDIA URL"); fieldLabel.setTextColor(0xffc7c7d1);
    fieldLabel.setTextSize(11); fieldLabel.setTypeface(null, Typeface.BOLD); fieldLabel.setPadding(0, 0, 0, dp(7)); panel.addView(fieldLabel);
    EditText url = new EditText(this); url.setSingleLine(true); url.setTextColor(Color.WHITE); url.setHintTextColor(0xff777783);
    url.setHint("Paste link here"); url.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
    url.setPadding(dp(13), dp(10), dp(13), dp(10)); GradientDrawable inputBg = new GradientDrawable();
    inputBg.setColor(0xff292932); inputBg.setCornerRadius(dp(12)); inputBg.setStroke(dp(1), 0xff41414d); url.setBackground(inputBg);
    String current = web != null ? web.getUrl() : ""; if (isYouTubeUrl(current)) url.setText(current);
    panel.addView(url, new LinearLayout.LayoutParams(-1, dp(52)));

    TextView status = new TextView(this); status.setText("Paste a link, then tap Check link"); status.setTextColor(0xffc3c3ce);
    status.setTextSize(12); status.setPadding(0, dp(12), 0, dp(8)); panel.addView(status);
    LinearLayout formats = new LinearLayout(this); formats.setOrientation(LinearLayout.VERTICAL); panel.addView(formats);
    final int[] selectedHeight = {-1}; final boolean[] audioSelected = {false};
    final boolean[] directMediaSelected = {false}; final String[] directMediaExt = {""};
    Button check = new Button(this); check.setText("Check link"); check.setAllCaps(false); check.setTextColor(Color.WHITE);
    check.setTypeface(null, Typeface.BOLD); check.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff30303a));
    LinearLayout.LayoutParams checkLp = new LinearLayout.LayoutParams(-1, dp(48)); checkLp.topMargin = dp(8); panel.addView(check, checkLp);

    LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setGravity(Gravity.CENTER_VERTICAL);
    Button cancel = new Button(this); cancel.setText("Cancel"); cancel.setAllCaps(false); cancel.setTextColor(0xffddddE5);
    cancel.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff34343e));
    Button download = new Button(this); download.setText("↓  Download"); download.setAllCaps(false); download.setTextColor(Color.WHITE);
    download.setTypeface(null, Typeface.BOLD); download.setEnabled(false);
    GradientDrawable downloadBg = new GradientDrawable(); downloadBg.setColor(0xff17171c); downloadBg.setCornerRadius(dp(28)); downloadBg.setStroke(dp(1), Color.WHITE); download.setBackground(downloadBg);
    LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(0, dp(48), 1); cLp.setMargins(0, dp(12), dp(8), 0);
    LinearLayout.LayoutParams dLp = new LinearLayout.LayoutParams(0, dp(48), 1); dLp.setMargins(0, dp(12), 0, 0);
    actions.addView(cancel, cLp); actions.addView(download, dLp); panel.addView(actions);

    dialog.setContentView(panel); Window window = dialog.getWindow();
    if (window != null) { window.setBackgroundDrawableResource(android.R.color.transparent); window.setLayout(-1, -2); window.setGravity(Gravity.BOTTOM);
      window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND); WindowManager.LayoutParams a = window.getAttributes(); a.dimAmount = 0.55f; window.setAttributes(a); window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE); }
    cancel.setOnClickListener(v -> dialog.dismiss());
    check.setOnClickListener(v -> {
      final String inputUrl = url.getText().toString().trim();
      selectedHeight[0] = -1; audioSelected[0] = false; directMediaSelected[0] = false; directMediaExt[0] = "";
      download.setEnabled(false); formats.removeAllViews(); status.setTextColor(0xffc3c3ce);

      // Direct, authorized media files are downloaded by Android DownloadManager.
      String extension = getDirectMediaExtension(inputUrl);
      if (extension != null) {
        directMediaSelected[0] = true; directMediaExt[0] = extension;
        status.setText("Direct media file detected. Only download files you own or have permission to save.");
        Button option = new Button(this); option.setText("Original file (" + extension.toUpperCase(java.util.Locale.US) + ")");
        option.setAllCaps(false); option.setTextColor(Color.WHITE);
        option.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff34343e));
        option.setOnClickListener(x -> { option.setAlpha(1f); download.setEnabled(true); status.setText("Ready to download the original " + extension.toUpperCase(java.util.Locale.US) + " file"); });
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, dp(44)); op.bottomMargin = dp(5); formats.addView(option, op);
        option.performClick();
        return;
      }

      if (!isYouTubeUrl(inputUrl)) { url.setError("Enter a valid YouTube link or direct MP4/WebM/MOV/M4V/MP3/M4A link"); return; }
      check.setEnabled(false); status.setText("Checking public video details…");
      new Thread(() -> {
        HttpURLConnection c = null;
        try {
          String endpoint = CLOUD_SERVER_URL + "/api/info?url=" + java.net.URLEncoder.encode(inputUrl, "UTF-8");
          c = (HttpURLConnection) new URL(endpoint).openConnection(); c.setConnectTimeout(20000); c.setReadTimeout(25000); c.setRequestMethod("GET");
          int code = c.getResponseCode(); java.io.InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
          String body = new String(readAll(stream), java.nio.charset.StandardCharsets.UTF_8); org.json.JSONObject data = new org.json.JSONObject(body);
          if (code != 200 || !data.optBoolean("ok")) throw new Exception(data.optString("error", "Could not read video details"));
          String videoTitle = data.optString("title", "YouTube video");
          String message = data.optString("message", "YouTube direct download is unavailable for this link.");
          runOnUiThread(() -> {
            formats.removeAllViews(); status.setText(videoTitle + "\n\n" + message);
            status.setTextColor(0xffffc27a);
            download.setEnabled(false);
            check.setEnabled(true);
          });
        } catch (Exception e) {
          runOnUiThread(() -> { status.setText("Video details unavailable: " + e.getMessage() + "\nYou can still use a creator-provided direct media link."); status.setTextColor(0xffff8b8b); check.setEnabled(true); });
        } finally { if (c != null) c.disconnect(); }
      }).start();
    });
    download.setOnClickListener(v -> {
      String inputUrl = url.getText().toString().trim();
      if (!directMediaSelected[0]) { status.setText("YouTube direct downloading is unavailable. Use the official YouTube Download feature where available, or paste an authorized direct media-file link."); status.setTextColor(0xffffc27a); return; }
      if (!directMediaUrlMatches(inputUrl, directMediaExt[0])) { status.setText("The media link changed. Tap Check link again."); return; }
      try {
        Uri uri = Uri.parse(inputUrl);
        String ext = directMediaExt[0];
        String name = "SocialHub_" + System.currentTimeMillis() + "." + ext;
        DownloadManager.Request req = new DownloadManager.Request(uri);
        req.setTitle("Social Hub download"); req.setDescription("Saving to Downloads/SocialHub");
        req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        req.setAllowedOverMetered(true); req.setAllowedOverRoaming(false);
        req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "SocialHub/" + name);
        long id = ((DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(req);
        if (id > 0) { Toast.makeText(this, "Download started. Check Android notifications.", Toast.LENGTH_LONG).show(); dialog.dismiss(); }
        else status.setText("Download could not be queued. Please try again.");
      } catch (Exception e) { status.setText("Download error: " + e.getMessage()); }
    });
    dialog.show(); if (window != null) window.setLayout(-1, -2);
    TranslateAnimation slideUp = new TranslateAnimation(0, 0, dp(420), 0); slideUp.setDuration(260); panel.startAnimation(slideUp);
  }

  private String getDirectMediaExtension(String raw) {
    try {
      Uri uri = Uri.parse(raw.trim()); String scheme = uri.getScheme(); String host = uri.getHost();
      if (!"https".equalsIgnoreCase(scheme) || host == null || isYouTubeUrl(raw)) return null;
      String path = uri.getPath(); if (path == null) return null;
      int dot = path.lastIndexOf('.'); if (dot < 0 || dot == path.length() - 1) return null;
      String ext = path.substring(dot + 1).toLowerCase(java.util.Locale.US);
      return ("mp4".equals(ext) || "webm".equals(ext) || "mov".equals(ext) || "m4v".equals(ext) || "mp3".equals(ext) || "m4a".equals(ext)) ? ext : null;
    } catch (Exception e) { return null; }
  }

  private boolean directMediaUrlMatches(String raw, String expectedExtension) {
    String actual = getDirectMediaExtension(raw);
    return actual != null && actual.equals(expectedExtension);
  }

  private byte[] readAll(java.io.InputStream in) throws java.io.IOException {
    try (java.io.InputStream input = in; java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
      byte[] buffer = new byte[8192]; int n; while ((n = input.read(buffer)) != -1) out.write(buffer, 0, n); return out.toByteArray();
    }
  }

  private boolean isYouTubeUrl(String raw) {
    try { Uri uri = Uri.parse(raw.trim()); String host = uri.getHost();
      return "https".equalsIgnoreCase(uri.getScheme()) && host != null && (host.equalsIgnoreCase("youtu.be") || host.equalsIgnoreCase("youtube.com") || host.endsWith(".youtube.com"));
    } catch (Exception e) { return false; }
  }

  @Override public void onBackPressed() {
    if (fullScreenCallback != null) { fullScreenCallback.onCustomViewHidden(); return; }
    if (landscape) { setLandscape(false); return; }
    if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
  }
  @Override public void onConfigurationChanged(android.content.res.Configuration newConfig) {
    super.onConfigurationChanged(newConfig);
    if (bar != null) bar.setVisibility(landscape ? View.GONE : View.VISIBLE);
    if (landscapeExitButton != null) landscapeExitButton.setVisibility(landscape ? View.VISIBLE : View.GONE);
    ViewCompat.requestApplyInsets(root);
  }
  @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if (hasFocus && landscape) applySystemBars(true); }
  @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }
}
