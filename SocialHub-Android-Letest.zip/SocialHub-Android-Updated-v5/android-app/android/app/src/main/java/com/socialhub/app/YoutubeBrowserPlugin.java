package com.socialhub.app;

import android.content.Intent;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "YoutubeBrowser")
public class YoutubeBrowserPlugin extends Plugin {
  @PluginMethod public void open(PluginCall call) {
    Intent intent = new Intent(getContext(), YoutubeBrowserActivity.class);
    intent.putExtra("url", "https://www.youtube.com");
    getActivity().startActivity(intent);
    call.resolve();
  }
}
