// Social Hub — Electron main process.
// Window: phone-style app (index.html). Sites open inside <webview> tags
// (partition "persist:socialhub") so YouTube / Instagram / TikTok stay in-app.
// Ad blocking: (1) network-level — known ad/tracker domains are cancelled in
// the webview session; (2) cosmetic — the renderer injects CSS/JS into the
// webview to hide ad slots and auto-skip video ads. Neither is 100%: sites
// change their ad code, and some ads are served from the site's own domain
// (YouTube video ads come from googlevideo.com, same as real videos).
const { app, BrowserWindow, session, ipcMain } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const { spawn } = require('node:child_process');

let adBlockEnabled = true;

// Known ad / tracker / ad-delivery hosts. Matched against the webview
// session only (partition "persist:socialhub").
const AD_URL_PATTERNS = [
  '*://*.doubleclick.net/*',
  '*://*.googlesyndication.com/*',
  '*://*.googleadservices.com/*',
  '*://*.adservice.google.com/*',
  '*://*.ads.youtube.com/*',
  '*://*.pagead2.googlesyndication.com/*',
  '*://*.googletagmanager.com/*',
  '*://*.googletagservices.com/*',
  '*://*.google-analytics.com/*',
  '*://*.adnxs.com/*',
  '*://*.adsrvr.org/*',
  '*://*.criteo.com/*',
  '*://*.criteo.net/*',
  '*://*.amazon-adsystem.com/*',
  '*://*.moatads.com/*',
  '*://*.scorecardresearch.com/*',
  '*://*.facebook.com/tr/*',
  '*://*.connect.facebook.net/*',
  '*://*.ads.tiktok.com/*',
  '*://*.analytics.tiktok.com/*'
];

function setupAdBlocking() {
  const ses = session.fromPartition('persist:socialhub');
  // A normal Chrome user-agent: some sites (Google sign-in) refuse Electron's
  // default UA ("This browser or app may not be secure").
  ses.setUserAgent(
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36'
  );
  ses.webRequest.onBeforeRequest({ urls: AD_URL_PATTERNS }, (details, callback) => {
    callback({ cancel: adBlockEnabled });
  });
}

function createWindow() {
  const win = new BrowserWindow({
    width: 480,
    height: 900,
    minWidth: 360,
    minHeight: 600,
    title: 'Social Hub',
    backgroundColor: '#0f0f12',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
      webviewTag: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
}

ipcMain.on('set-adblock', (_event, on) => {
  adBlockEnabled = !!on;
});

// ---------- Download Manager ----------
// Downloads YouTube videos with yt-dlp (expected at <app>/bin/yt-dlp).
// yt-dlp is NOT bundled and NOT downloaded here (needs the user's approval
// first: ~13 MB yt-dlp + ~25 MB ffmpeg). Without it the handler returns a
// clear 'missing-ytdlp' error and the app keeps working.
const YTDLP_PATH = path.join(__dirname, 'bin', 'yt-dlp');
const BIN_DIR = path.join(__dirname, 'bin'); // ffmpeg lives next to yt-dlp
const DOWNLOAD_DIR = path.join(os.homedir(), 'Downloads', 'Social Hub');

let downloadInProgress = false; // one download at a time — no parallel yt-dlp runs

// Delete only incomplete-download leftovers (.part/.temp/.ytdl). Completed
// videos are never touched. Runs on startup and after a failed download.
function cleanupLeftovers() {
  let files = [];
  try { files = fs.readdirSync(DOWNLOAD_DIR); } catch (e) { return; }
  for (const f of files) {
    if (/\.(part|temp|ytdl)$/i.test(f)) {
      try { fs.unlinkSync(path.join(DOWNLOAD_DIR, f)); } catch (e) {}
    }
  }
}

function findYtDlp() {
  try {
    if (fs.existsSync(YTDLP_PATH)) return YTDLP_PATH;
  } catch (e) {}
  return null;
}

ipcMain.handle('download-video', async (event, { url, format }) => {
  const ytdlp = findYtDlp();
  if (!ytdlp) return { ok: false, error: 'missing-ytdlp' };
  if (!url || !/^https?:\/\/(www\.)?(youtube\.com|youtu\.be)\//.test(url)) {
    return { ok: false, error: 'Not a YouTube URL.' };
  }
  if (downloadInProgress) return { ok: false, error: 'busy' };
  downloadInProgress = true;
  try {
    fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });
  } catch (e) {
    downloadInProgress = false;
    return { ok: false, error: 'Could not create download folder: ' + e.message };
  }
  const outTemplate = path.join(DOWNLOAD_DIR, '%(title)s.%(ext)s');
  // --no-playlist: a watch URL from a Mix/playlist page must NOT pull the
  // whole playlist — only the one video the user picked.
  // --remux-video mp4: final video is always .mp4 (container change only,
  // no re-encode). --newline: progress comes as parseable lines.
  const common = ['--no-playlist', '--no-write-thumbnail', '--no-write-info-json',
    '--no-write-subs', '--no-write-auto-subs', '--newline', '--ffmpeg-location', BIN_DIR];
  let args;
  if (format === 'mp3') {
    args = common.concat(['-x', '--audio-format', 'mp3', '--print', 'after_move:filepath', '-o', outTemplate, url]);
  } else {
    // Any height works now ('2160p', '480p', '144p', ...): the panel lists
    // the video's real heights, so parse the number out of the format id.
    const hm = /^(\d+)p$/.exec(format || '');
    const height = hm ? parseInt(hm[1], 10) : 720;
    args = common.concat(['--remux-video', 'mp4', '-f',
      'bestvideo[height<=' + height + ']+bestaudio/best[height<=' + height + ']/best',
      '--print', 'after_move:filepath', '-o', outTemplate, url]);
  }
  const sendProgress = (data) => {
    try { event.sender.send('download-progress', data); } catch (e) {}
  };
  return new Promise((resolve) => {
    const child = spawn(ytdlp, args);
    let stderr = '';
    let stdoutBuf = '';
    let finalFile = '';
    const finish = (result) => { downloadInProgress = false; resolve(result); };
    child.stdout.on('data', (d) => {
      stdoutBuf += d.toString();
      const lines = stdoutBuf.split('\n');
      stdoutBuf = lines.pop();
      for (const line of lines) {
        const m = line.match(/\[download\]\s+(\d+(?:\.\d+)?)%\s+of\s+(\S+)(?:\s+at\s+(\S+))?(?:\s+ETA\s+(\S+))?/);
        if (m) {
          sendProgress({ percent: parseFloat(m[1]), total: m[2], speed: m[3] || '', eta: m[4] || '' });
        } else if (/^\[Merger\]/.test(line)) {
          sendProgress({ phase: 'merging' });
        } else if (/^\[ExtractAudio\]/.test(line)) {
          sendProgress({ phase: 'extracting' });
        } else if (line.trim() && line.trim()[0] !== '[' && /\.(mp4|mp3|webm|m4a)$/i.test(line.trim())) {
          finalFile = line.trim();
        }
      }
    });
    child.stderr.on('data', (d) => { stderr += d.toString(); });
    child.on('error', (e) => {
      cleanupLeftovers();
      finish({ ok: false, error: 'Could not run yt-dlp: ' + e.message });
    });
    child.on('close', (code) => {
      if (code === 0) {
        sendProgress({ percent: 100, done: true, file: finalFile });
        finish({ ok: true, file: finalFile || DOWNLOAD_DIR });
      } else {
        cleanupLeftovers();
        const tail = stderr.trim().split('\n').slice(-3).join(' ');
        finish({ ok: false, error: tail || ('yt-dlp exited with code ' + code) });
      }
    });
  });
});

// ---------- Available formats ----------
// Returns the video's real heights (e.g. [1080, 720, 480, 360, 240, 144])
// so the panel lists exactly what this video offers — no fixed list.
// Uses yt-dlp -J (full info JSON); on any failure returns ok:false and the
// renderer falls back to the fixed 1080/720/360 list.
ipcMain.handle('get-video-formats', async (_event, { url }) => {
  const ytdlp = findYtDlp();
  if (!ytdlp) return { ok: false, error: 'missing-ytdlp' };
  if (!url || !/^https?:\/\/(www\.)?(youtube\.com|youtu\.be)\//.test(url)) {
    return { ok: false, error: 'Not a YouTube URL.' };
  }
  return new Promise((resolve) => {
    const child = spawn(ytdlp, ['--no-playlist', '--no-warnings', '-J', url]);
    let out = '';
    let err = '';
    const timer = setTimeout(() => { try { child.kill(); } catch (e) {} }, 30000);
    child.stdout.on('data', (d) => { out += d.toString(); });
    child.stderr.on('data', (d) => { err += d.toString(); });
    child.on('error', (e) => {
      clearTimeout(timer);
      resolve({ ok: false, error: 'Could not run yt-dlp: ' + e.message });
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (code !== 0) {
        const tail = err.trim().split('\n').slice(-2).join(' ');
        resolve({ ok: false, error: tail || ('yt-dlp exited with code ' + code) });
        return;
      }
      try {
        const info = JSON.parse(out);
        const heights = new Set();
        let hasAudio = false;
        for (const f of info.formats || []) {
          if (f.vcodec && f.vcodec !== 'none' && f.height) heights.add(f.height);
          if (f.acodec && f.acodec !== 'none') hasAudio = true;
        }
        const list = Array.from(heights).sort((a, b) => b - a);
        resolve({ ok: true, heights: list, hasAudio });
      } catch (e) {
        resolve({ ok: false, error: 'Could not parse video info.' });
      }
    });
  });
});

app.whenReady().then(() => {
  setupAdBlocking();
  cleanupLeftovers();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
