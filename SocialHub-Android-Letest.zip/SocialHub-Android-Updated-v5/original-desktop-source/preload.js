// Social Hub — preload script (contextIsolation: true).
// Exposes a tiny, safe API to the renderer: is this the Electron app, and
// tell the main process when AdBlock is toggled. No Node access in the page.
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  isElectron: true,
  setAdBlock: (on) => ipcRenderer.send('set-adblock', on),
  downloadVideo: (url, format) => ipcRenderer.invoke('download-video', { url, format }),
  getVideoFormats: (url) => ipcRenderer.invoke('get-video-formats', { url }),
  onDownloadProgress: (cb) => ipcRenderer.on('download-progress', (_e, data) => cb(data))
});
