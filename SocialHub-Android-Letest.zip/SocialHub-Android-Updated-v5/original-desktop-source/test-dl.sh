#!/bin/zsh
cd "/Users/shamas/Desktop/my apps"
./bin/yt-dlp --ffmpeg-location bin -f 'bestvideo[height<=720]+bestaudio/best' -o "$HOME/Downloads/Social Hub/Rick.%(ext)s" 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'
