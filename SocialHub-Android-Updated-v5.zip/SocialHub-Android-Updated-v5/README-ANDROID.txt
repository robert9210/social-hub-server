SOCIAL HUB ANDROID - UPDATED SOURCE (V6)

This project keeps the original desktop source in original-desktop-source and the Android Capacitor project in android-app.

ANDROID FEATURES RETAINED
- YouTube opens in the native in-app Android WebView.
- Best-effort filtering of selected advertising domains and ad containers. This is not a guarantee that all YouTube ads are blocked.
- Player-only upward swipe and full-screen landscape controls, preserving the current playback session where supported.
- Android safe-area spacing for status/navigation bars.
- Redesigned native Download button and bottom-sheet Download Manager.

DOWNLOAD MANAGER
- Accepts authorized direct media-file URLs ending in MP4, WebM, MOV, M4V, MP3, or M4A.
- Opens the YTDown website (https://app.ytdown.to/en38/) inside the native Download Manager panel, beneath the Social Hub header.
- The embedded WebView handles the website workflow; Android DownloadManager catches supported file-download events and saves them under Downloads/SocialHub.
- Download notifications are shown by Android. Website availability and download support depend on the site and the source link. The app does not bypass DRM, sign-in requirements, access controls, or platform restrictions; only save media you are authorized to download.
- The app does not bypass DRM, login requirements, access controls, or platform restrictions.

BUILD ON MAC
1. Open Terminal in the android-app folder.
2. Run: npm install
3. Run: npx cap sync android
4. Open Android Studio: npx cap open android
5. Build the debug APK from Android Studio.

The local.properties file and generated build/cache folders are intentionally not included in the cleaned source ZIP. Android Studio will use the SDK configured on your Mac.
