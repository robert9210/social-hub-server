package com.socialhub.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.DownloadListener;
import android.webkit.WebSettings;
import android.webkit.URLUtil;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.FrameLayout;
import android.app.Dialog;
import android.graphics.drawable.GradientDrawable;
import android.view.animation.TranslateAnimation;
import android.view.Window;
import android.view.WindowManager;
import java.net.HttpURLConnection;
import java.net.URL;
import android.os.Environment;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import android.webkit.JavascriptInterface;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class YoutubeBrowserActivity extends Activity {
  private static final String CLOUD_SERVER_URL = "https://social-hub-server-avmq.onrender.com";
  private WebView web;
  private WebView downloadWebView;
  private Dialog downloadDialog;
  private FrameLayout root;
  private LinearLayout column;
  private LinearLayout bar;
  private Button landscapeButton;
  private Button landscapeExitButton;
  private FrameLayout fullScreenContainer;
  private WebChromeClient.CustomViewCallback fullScreenCallback;
  private boolean landscape = false;
  private boolean adBlock = true;
  private final Set<String> blocked = new HashSet<>(Arrays.asList(
    "doubleclick.net", "googlesyndication.com", "googleadservices.com",
    "adservice.google.com", "imasdk.googleapis.com", "pagead2.googlesyndication.com"));
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(0xff15151b);
    getWindow().setNavigationBarColor(0xff15151b);
    root = new FrameLayout(this); root.setBackgroundColor(0xff101014);
    // Keep app controls inside the safe area, below the status bar and above navigation keys.
    ViewCompat.setOnApplyWindowInsetsListener(root, (view, windowInsets) -> {
      Insets systemBars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
      view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
      return windowInsets;
    });
    column = new LinearLayout(this); column.setOrientation(LinearLayout.VERTICAL); root.addView(column, new FrameLayout.LayoutParams(-1, -1));
    bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(8,6,8,6); bar.setBackgroundColor(0xff202027);
    Button back = makeBarButton("‹", "Back"); back.setOnClickListener(v -> finish());
    TextView label = new TextView(this); label.setText("YouTube  •  AdBlock"); label.setTextColor(0xffffffff); label.setTextSize(13); label.setGravity(Gravity.CENTER_VERTICAL); label.setSingleLine(true);
    landscapeButton = makeBarButton("⛶", "Full screen"); landscapeButton.setOnClickListener(v -> setLandscape(!landscape));
    Button download = makeDownloadButton(); download.setOnClickListener(v -> showDownloadDialog());
    bar.addView(back); bar.addView(label, new LinearLayout.LayoutParams(0, 48, 1)); bar.addView(landscapeButton); bar.addView(download); column.addView(bar);
    landscapeExitButton = makeBarButton("↙", "Exit landscape");
    landscapeExitButton.setVisibility(View.GONE);
    landscapeExitButton.setOnClickListener(v -> { if (fullScreenCallback != null) fullScreenCallback.onCustomViewHidden(); else setLandscape(false); });
    FrameLayout.LayoutParams exitLp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END); exitLp.setMargins(0, 12, 12, 0); root.addView(landscapeExitButton, exitLp);
    // Do not listen for gestures on the whole WebView: feed scrolling must remain normal.
    // The injected page script reports an upward swipe only when it starts on the video player.
    web = new WebView(this);
    web.addJavascriptInterface(new PlayerGestureBridge(), "SocialHubPlayer");
    web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setMediaPlaybackRequiresUserGesture(false);
    CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
    web.setWebChromeClient(new WebChromeClient() {
      @Override public void onShowCustomView(View view, CustomViewCallback callback) {
        if (fullScreenContainer != null) { callback.onCustomViewHidden(); return; }
        fullScreenCallback = callback;
        fullScreenContainer = new FrameLayout(YoutubeBrowserActivity.this);
        fullScreenContainer.setBackgroundColor(Color.BLACK);
        fullScreenContainer.addView(view, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        web.setVisibility(View.GONE);
        root.addView(fullScreenContainer, new FrameLayout.LayoutParams(-1, -1));
        setLandscape(true);
        landscapeExitButton.bringToFront();
      }
      @Override public void onHideCustomView() {
        if (fullScreenContainer != null) {
          root.removeView(fullScreenContainer); fullScreenContainer = null;
          web.setVisibility(View.VISIBLE);
        }
        fullScreenCallback = null;
        setLandscape(false);
      }
    });
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
      @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        if (adBlock) { String host = request.getUrl().getHost(); if (host != null) for (String d : blocked) if (host.equals(d) || host.endsWith("."+d)) return new android.webkit.WebResourceResponse("text/plain", "utf-8", new java.io.ByteArrayInputStream(new byte[0])); }
        return super.shouldInterceptRequest(view, request);
      }
      @Override public void onPageFinished(WebView view, String url) {
        if (adBlock) view.evaluateJavascript("(function(){var s=document.createElement('style');s.textContent='ytd-ad-slot-renderer,ytd-display-ad-renderer,ytd-promoted-sparkles-web-renderer,#player-ads,#masthead-ad,.video-ads{display:none!important}';document.documentElement.appendChild(s);})();", null);
        installPlayerOnlySwipe(view);
      }
    });
    column.addView(web, new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    ViewCompat.requestApplyInsets(root);
    web.loadUrl(getIntent().getStringExtra("url") == null ? "https://www.youtube.com" : getIntent().getStringExtra("url"));
  }

  private void installPlayerOnlySwipe(WebView target) {
    String script = "(function(){" +
      "if(window.__socialHubPlayerSwipeInstalled)return;window.__socialHubPlayerSwipeInstalled=true;" +
      "var start=null;" +
      "function playerAt(x,y,e){var path=(e&&e.composedPath)?e.composedPath():[];var candidates=path.slice();var el=document.elementFromPoint(x,y);if(el)candidates.push(el);" +
      "for(var i=0;i<candidates.length;i++){var n=candidates[i];if(!n||!n.getBoundingClientRect)continue;var isPlayer=(n.tagName==='VIDEO')||(n.id==='movie_player')||(n.classList&&(n.classList.contains('html5-video-player')||n.classList.contains('ytp-remote')))||(n.tagName&&n.tagName.toLowerCase()==='ytd-player');" +
      "if(isPlayer){var v=n.tagName==='VIDEO'?n:(n.querySelector?n.querySelector('video'):null);var r=(v||n).getBoundingClientRect();if(x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom)return true;}}return false;}" +
      "document.addEventListener('touchstart',function(e){var t=e.touches&&e.touches[0];if(!t)return;start=playerAt(t.clientX,t.clientY,e)?{x:t.clientX,y:t.clientY,time:Date.now()}:null;},{capture:true,passive:true});" +
      "document.addEventListener('touchend',function(e){if(!start)return;var t=e.changedTouches&&e.changedTouches[0];var s=start;start=null;if(!t)return;var dx=t.clientX-s.x,dy=t.clientY-s.y;if(dy < -125&&Math.abs(dy)>Math.abs(dx)*1.3&&Date.now()-s.time<1400&&window.SocialHubPlayer){window.SocialHubPlayer.enterLandscapeFromPlayer();}},{capture:true,passive:true});" +
      "document.addEventListener('touchcancel',function(){start=null;},{capture:true,passive:true});" +
      "})();";
    target.evaluateJavascript(script, null);
  }

  private class PlayerGestureBridge {
    @JavascriptInterface public void enterLandscapeFromPlayer() {
      runOnUiThread(() -> { if (!landscape && fullScreenContainer == null) setLandscape(true); });
    }
  }

  private Button makeBarButton(String symbol, String description) {
    Button b = new Button(this); b.setText(symbol); b.setTextColor(Color.WHITE); b.setTextSize(18); b.setTypeface(null, Typeface.BOLD);
    b.setAllCaps(false); b.setMinWidth(48); b.setMinimumWidth(48); b.setMinHeight(46); b.setMinimumHeight(46);
    b.setPadding(8,0,8,0); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff30303a)); b.setContentDescription(description); return b;
  }
  private void setLandscape(boolean enabled) {
    landscape = enabled;
    setRequestedOrientation(enabled ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    if (landscapeButton != null) landscapeButton.setText(enabled ? "↙" : "⛶");
    if (bar != null) bar.setVisibility(enabled ? View.GONE : View.VISIBLE);
    if (landscapeExitButton != null) landscapeExitButton.setVisibility(enabled ? View.VISIBLE : View.GONE);
    applySystemBars(enabled);
  }
  private void applySystemBars(boolean immersive) {
    if (android.os.Build.VERSION.SDK_INT >= 30) {
      Window w = getWindow();
      if (immersive) w.getInsetsController().hide(android.view.WindowInsets.Type.statusBars() | android.view.WindowInsets.Type.navigationBars());
      else w.getInsetsController().show(android.view.WindowInsets.Type.statusBars() | android.view.WindowInsets.Type.navigationBars());
    } else {
      int flags = immersive ? (View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY) : View.SYSTEM_UI_FLAG_VISIBLE;
      getWindow().getDecorView().setSystemUiVisibility(flags);
    }
  }
  private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

  private Button makeDownloadButton() {
    Button b = new Button(this);
    b.setText("↓  Download"); b.setTextColor(0xff17171c); b.setTextSize(14);
    b.setTypeface(null, Typeface.BOLD); b.setAllCaps(false);
    b.setPadding(dp(17), 0, dp(17), 0); b.setMinWidth(0); b.setMinimumWidth(0);
    b.setMinHeight(dp(42)); b.setMinimumHeight(dp(42));
    GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.WHITE);
    bg.setCornerRadius(dp(30)); bg.setStroke(dp(1.5f), 0xff17171c);
    b.setBackground(bg); b.setContentDescription("Download");
    return b;
  }

  private void showDownloadDialog() {
    if (downloadDialog != null && downloadDialog.isShowing()) return;

    Dialog dialog = new Dialog(this);
    downloadDialog = dialog;
    LinearLayout panel = new LinearLayout(this);
    panel.setOrientation(LinearLayout.VERTICAL);
    panel.setBackgroundColor(0xff101014);

    LinearLayout header = new LinearLayout(this);
    header.setOrientation(LinearLayout.HORIZONTAL);
    header.setGravity(Gravity.CENTER_VERTICAL);
    header.setPadding(dp(16), dp(8), dp(10), dp(8));
    header.setBackgroundColor(0xff202027);

    LinearLayout heading = new LinearLayout(this);
    heading.setOrientation(LinearLayout.VERTICAL);
    TextView title = new TextView(this);
    title.setText("Social Hub  •  Download Manager");
    title.setTextColor(Color.WHITE);
    title.setTextSize(16);
    title.setTypeface(null, Typeface.BOLD);
    TextView subtitle = new TextView(this);
    subtitle.setText("Choose your link and download options on the website");
    subtitle.setTextColor(0xffb8b8c4);
    subtitle.setTextSize(11);
    heading.addView(title);
    heading.addView(subtitle);
    header.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));

    Button close = makeBarButton("✕", "Close Download Manager");
    close.setOnClickListener(v -> dialog.dismiss());
    header.addView(close);
    panel.addView(header, new LinearLayout.LayoutParams(-1, -2));

    android.widget.ProgressBar progress = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
    progress.setMax(100);
    progress.setProgress(0);
    progress.setVisibility(View.GONE);
    panel.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));

    WebView downloader = new WebView(this);
    downloadWebView = downloader;
    ArrayList<WebView> popupWebViews = new ArrayList<>();
    WebSettings settings = downloader.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setDatabaseEnabled(true);
    settings.setLoadsImagesAutomatically(true);
    settings.setAllowFileAccess(false);
    settings.setAllowContentAccess(false);
    if (android.os.Build.VERSION.SDK_INT >= 21) settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    settings.setJavaScriptCanOpenWindowsAutomatically(true);
    settings.setSupportMultipleWindows(true);
    settings.setMediaPlaybackRequiresUserGesture(false);
    settings.setUseWideViewPort(true);
    settings.setLoadWithOverviewMode(true);
    settings.setDefaultTextEncodingName("UTF-8");
    CookieManager cookieManager = CookieManager.getInstance();
    cookieManager.setAcceptCookie(true);
    cookieManager.setAcceptThirdPartyCookies(downloader, true);

    downloader.setBackgroundColor(Color.WHITE);
    downloader.setWebChromeClient(new WebChromeClient() {
      @Override public void onProgressChanged(WebView view, int newProgress) {
        progress.setProgress(newProgress);
        progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
      }

      @Override public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, android.os.Message resultMsg) {
        WebView popup = new WebView(YoutubeBrowserActivity.this);
        popupWebViews.add(popup);
        popup.getSettings().setJavaScriptEnabled(true);
        popup.setWebViewClient(new WebViewClient() {
          @Override public boolean shouldOverrideUrlLoading(WebView popupView, WebResourceRequest request) {
            downloader.loadUrl(request.getUrl().toString());
            return true;
          }
          @Override public void onPageStarted(WebView popupView, String url, android.graphics.Bitmap favicon) {
            if (url != null && !"about:blank".equals(url)) {
              downloader.loadUrl(url);
              popupView.stopLoading();
            }
          }
        });
        FrameLayout hiddenPopupHost = new FrameLayout(YoutubeBrowserActivity.this);
        hiddenPopupHost.setVisibility(View.GONE);
        hiddenPopupHost.addView(popup, new FrameLayout.LayoutParams(1, 1));
        panel.addView(hiddenPopupHost, new LinearLayout.LayoutParams(1, 1));
        WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
        transport.setWebView(popup);
        resultMsg.sendToTarget();
        return true;
      }
    });
    downloader.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        String scheme = request.getUrl().getScheme();
        return !("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme));
      }
    });
    downloader.setDownloadListener((downloadUrl, userAgent, contentDisposition, mimeType, contentLength) -> {
      try {
        Uri uri = Uri.parse(downloadUrl);
        String scheme = uri.getScheme();
        if (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme)) {
          Toast.makeText(this, "This download link is not supported.", Toast.LENGTH_LONG).show();
          return;
        }

        String fileName = URLUtil.guessFileName(downloadUrl, contentDisposition, mimeType);
        if (fileName == null || fileName.trim().isEmpty()) {
          fileName = "SocialHub_" + System.currentTimeMillis();
        }
        fileName = fileName.replaceAll("[/\\\\\\\\:*?\"<>|]", "_");

        DownloadManager.Request request = new DownloadManager.Request(uri);
        request.setTitle(fileName);
        request.setDescription("Downloading with Social Hub");
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setAllowedOverMetered(true);
        request.setAllowedOverRoaming(false);
        if (mimeType != null && !mimeType.trim().isEmpty()) request.setMimeType(mimeType);
        if (userAgent != null && !userAgent.trim().isEmpty()) request.addRequestHeader("User-Agent", userAgent);
        String cookies = CookieManager.getInstance().getCookie(downloadUrl);
        if (cookies != null && !cookies.isEmpty()) request.addRequestHeader("Cookie", cookies);
        String referer = downloader.getUrl();
        if (referer != null && !referer.isEmpty()) request.addRequestHeader("Referer", referer);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "SocialHub/" + fileName);
        long downloadId = ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(request);
        if (downloadId > 0) {
          Toast.makeText(this, "Download started. Check Android notifications.", Toast.LENGTH_LONG).show();
        } else {
          Toast.makeText(this, "Download could not be started. Please try again.", Toast.LENGTH_LONG).show();
        }
      } catch (Exception e) {
        Toast.makeText(this, "Download error: " + e.getMessage(), Toast.LENGTH_LONG).show();
      }
    });

    panel.addView(downloader, new LinearLayout.LayoutParams(-1, 0, 1));
    dialog.setContentView(panel);
    Window window = dialog.getWindow();
    if (window != null) {
      window.setBackgroundDrawableResource(android.R.color.transparent);
      window.setLayout(-1, (int) (getResources().getDisplayMetrics().heightPixels * 0.88f));
      window.setGravity(Gravity.BOTTOM);
      window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
      WindowManager.LayoutParams attrs = window.getAttributes();
      attrs.dimAmount = 0.45f;
      window.setAttributes(attrs);
      window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }
    dialog.setOnDismissListener(d -> {
      if (downloadWebView == downloader) downloadWebView = null;
      downloader.stopLoading();
      downloader.destroy();
      for (WebView popup : popupWebViews) { popup.stopLoading(); popup.destroy(); }
      if (downloadDialog == dialog) downloadDialog = null;
    });
    dialog.show();
    if (window != null) window.setLayout(-1, (int) (getResources().getDisplayMetrics().heightPixels * 0.88f));
    downloader.loadUrl("https://app.ytdown.to/en38/");
  }

  private String getDirectMediaExtension(String raw) {
    try {
      Uri uri = Uri.parse(raw.trim()); String scheme = uri.getScheme(); String host = uri.getHost();
      if (!"https".equalsIgnoreCase(scheme) || host == null || isYouTubeUrl(raw)) return null;
      String path = uri.getPath(); if (path == null) return null;
      int dot = path.lastIndexOf('.'); if (dot < 0 || dot == path.length() - 1) return null;
      String ext = path.substring(dot + 1).toLowerCase(java.util.Locale.US);
      return ("mp4".equals(ext) || "webm".equals(ext) || "mov".equals(ext) || "m4v".equals(ext) || "mp3".equals(ext) || "m4a".equals(ext)) ? ext : null;
    } catch (Exception e) { return null; }
  }

  private boolean directMediaUrlMatches(String raw, String expectedExtension) {
    String actual = getDirectMediaExtension(raw);
    return actual != null && actual.equals(expectedExtension);
  }

  private byte[] readAll(java.io.InputStream in) throws java.io.IOException {
    try (java.io.InputStream input = in; java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
      byte[] buffer = new byte[8192]; int n; while ((n = input.read(buffer)) != -1) out.write(buffer, 0, n); return out.toByteArray();
    }
  }

  private boolean isYouTubeUrl(String raw) {
    try { Uri uri = Uri.parse(raw.trim()); String host = uri.getHost();
      return "https".equalsIgnoreCase(uri.getScheme()) && host != null && (host.equalsIgnoreCase("youtu.be") || host.equalsIgnoreCase("youtube.com") || host.endsWith(".youtube.com"));
    } catch (Exception e) { return false; }
  }

  @Override public void onBackPressed() {
    if (downloadDialog != null && downloadDialog.isShowing()) {
      if (downloadWebView != null && downloadWebView.canGoBack()) downloadWebView.goBack();
      else downloadDialog.dismiss();
      return;
    }
    if (fullScreenCallback != null) { fullScreenCallback.onCustomViewHidden(); return; }
    if (landscape) { setLandscape(false); return; }
    if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
  }
  @Override public void onConfigurationChanged(android.content.res.Configuration newConfig) {
    super.onConfigurationChanged(newConfig);
    if (bar != null) bar.setVisibility(landscape ? View.GONE : View.VISIBLE);
    if (landscapeExitButton != null) landscapeExitButton.setVisibility(landscape ? View.VISIBLE : View.GONE);
    ViewCompat.requestApplyInsets(root);
  }
  @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if (hasFocus && landscape) applySystemBars(true); }
  @Override protected void onDestroy() { if (downloadDialog != null && downloadDialog.isShowing()) downloadDialog.dismiss(); if (web != null) web.destroy(); super.onDestroy(); }
}
